import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))


import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import seaborn as sns
import matplotlib.pyplot as plt

#Read a excel file ......
df = pd.read_excel(r"C:\Users\jaspr\Downloads\Copy of orders_data.xlsx")

# print a df head rows of file.......
print(df.head)

# print shape of file .......
print(df.shape)

# checking a null values in file......
x = df.isnull().sum()
print(x)
# checking a columns in file
print(df.columns)

# droping a null values ......
drop_df= df.dropna()
print(drop_df)

#checking a drop values in columns...
values=df.isnull().sum()
print(values)

data=df.describe(include="all")
print(data)

data = df.info()
print(data)

data=[featers for featers in df.columns if df[featers].isnull().sum()]
print(data)

# cleaning a data ....

data = df["order_date"]= pd.to_datetime(df["order_date"])
data = df["order_year"]=df["order_date"].dt.year
data = df["order_month"]=df["order_date"].dt.month
data = df["order_week"]=df["order_date"].dt.week
data = df["order_day"]=df["order_date"].dt.day
data = df["order_weekday"]=df["order_date"].dt.weekday
data = df["order_time"]=df["order_date"].dt.time
data = df["order_date_extracted"]=df["order_date"].dt.date
data =df.drop("order_date",axis=1, inplace=True)
print(data)

#removing comma from city and state and make in upper case ....

location = ['ship_city', 'ship_state']
for i in location:
    df[i]= df[i].apply(lambda x: x.replace(',', '').upper())
    df["buyer"]= df["buyer"].apply(lambda x: x.upper())
    df["sku"]= df["sku"].apply(lambda x: x[5:])
    df["sku"]= df["sku"].str.replace('-',"")
    df["sku"] = df["sku"].apply(lambda x: x.replace(' ',''))

# remove rupee symbol and commas from amount features....

amounts = ["item_total","shipping_fee"]
for i in amounts:
    df[i]=pd.to_numeric(df[i].str.replace(',',"").str.extract(r'([\d)+\.[\d]+)')[0])

#The method of payment should be cash on delivery otherwise online.

data = df["cod"].fillna("online",inplace=True)

#There are still some null values in item_total and shipping_fee

"""plt.figure(figsize=(15,6))
plt.subplot(1,2,1)
sns.violinplot(x=df.item_total)
plt.subplot(1,2,2)
sns.violinplot(x=df.shipping_fee)
plt.show()"""

# impute missing values via simpleImputer by using strategy=median
from sklearn.impute import SimpleImputer

Imputer = SimpleImputer(missing_values = np.nan, strategy="median")
df[['item_total','shipping_fee']]=Imputer.fit_transform(df[['item_total','shipping_fee']])

data = df.describe(include="all")
print(data)

#Sales based on cities and states....

"""plt.figure(figsize=(20,6))
ax1= plt.subplot(1,2,1)
plt.title("total sale of item by state")
data_ship_state= data.groupby("ship_state").aggregate("sum").sort_values("item_total", ascending=False)
sns.barplot(y=data_ship_state.index,x=data_ship_state["item_total"])

ax2 = plt.subplot(1,2,2)
plt.title("total quantity of item by state")
data_ship_state= data.groupby("ship_state").aggregate("sum").sort_values("quantity", ascending=False)
sns.barplot(y=data_ship_state.index,x=data_ship_state["quantity"])
plt.show()"""

print(df.head(2))

data_hist= df[['cod','order_status', 'item_total']].groupby(['cod','order_status']).sum().reset_index()
print(data_hist)
sns.barplot(data=data_hist,x='cod',y='item_total',hue='order_status')
#plt.show()

print("The percentage of returned to seller for Online Sales")
print("{:.2f} %".format(data_hist.loc[3,"item_total"]/data_hist.loc[2,"item_total"]*100))
print("The percentage of returned to seller for Cash on Delivery")
print("{:.2f} %".format(data_hist.loc[1,"item_total"]/data_hist.loc[0,"item_total"]*100))

data_hist=df[['cod', 'shipping_fee','quantity']].groupby(['cod']).sum().reset_index()
data_hist["fee per quantity"]=data_hist["shipping_fee"]/data_hist["quantity"]
print(data_hist)

data_sku=df.groupby(['sku','order_status']).agg({'order_status':'count',})
data_sku.rename(columns={"order_status":"count"},inplace=True)
data_sku.sort_values(by="count",ascending=False,inplace=True)
data_sku.reset_index(inplace=True)
data_sku_returned=data_sku.loc[data_sku['order_status']=='Returned to seller',:]
sns.barplot(data=data_sku_returned,y="sku",x="count")
plt.figure(figsize=(15,6))
plt.show()




